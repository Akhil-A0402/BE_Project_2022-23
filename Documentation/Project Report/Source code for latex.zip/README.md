(CC BY-NC-SA 4.0)

This version of this template was made by Nikhil Alex V., BSMS '17.

The original IISER TVM thesis style was modified into a template with inspiration from the efforts of other Indian Institutes.

This template has been modified to meet the IISER Thiruvananthapuram dissertation/thesis requirements while also providing new users with an in-depth look at making use of the many features LateX has to offer.

Much improvement is needed to match this format to the levels of those of IISER Thiruvananthapuram's current academic contemporaries. Those interested in assisting with the effort may contact [nikhil.alexv17@alumni.iisertvm.ac.in]. 